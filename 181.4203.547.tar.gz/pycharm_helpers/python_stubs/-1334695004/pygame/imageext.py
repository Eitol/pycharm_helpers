# encoding: utf-8
# module pygame.imageext
# from /usr/lib/python3/dist-packages/pygame/imageext.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
""" additional image loaders """
# no imports

# functions

def load_extended(*args, **kwargs): # real signature unknown
    """ pygame module for image transfer """
    pass

def save_extended(*args, **kwargs): # real signature unknown
    """ pygame module for image transfer """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

