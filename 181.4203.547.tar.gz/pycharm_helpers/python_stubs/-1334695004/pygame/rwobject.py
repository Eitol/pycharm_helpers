# encoding: utf-8
# module pygame.rwobject
# from /usr/lib/python3/dist-packages/pygame/rwobject.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
""" SDL_RWops support """
# no imports

# functions

def encode_file_path(obj=None, etype=None): # real signature unknown; restored from __doc__
    """
    encode_file_path([obj [, etype]]) -> bytes or None
    Encode a unicode or bytes object as a file system path
    """
    return b""

def encode_string(obj=None, encoding=None, errors=None, etype=None): # real signature unknown; restored from __doc__
    """
    encode_string([obj [, encoding [, errors [, etype]]]]) -> bytes or None
    Encode a unicode or bytes object
    """
    return b""

# no classes
# variables with complex values

_PYGAME_C_API = None # (!) real value is ''

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

