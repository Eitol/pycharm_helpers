# encoding: utf-8
# module pygame.surflock
# from /usr/lib/python3/dist-packages/pygame/surflock.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
""" Surface locking support """
# no imports

# no functions
# no classes
# variables with complex values

_PYGAME_C_API = None # (!) real value is ''

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

