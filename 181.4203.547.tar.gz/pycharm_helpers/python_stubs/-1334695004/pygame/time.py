# encoding: utf-8
# module pygame.time
# from /usr/lib/python3/dist-packages/pygame/time.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
""" pygame module for monitoring time """
# no imports

# functions

def Clock(): # real signature unknown; restored from __doc__
    """
    Clock() -> Clock
    create an object to help track time
    """
    pass

def delay(milliseconds): # real signature unknown; restored from __doc__
    """
    delay(milliseconds) -> time
    pause the program for an amount of time
    """
    pass

def get_ticks(): # real signature unknown; restored from __doc__
    """
    get_ticks() -> milliseconds
    get the time in milliseconds
    """
    pass

def set_timer(eventid, milliseconds): # real signature unknown; restored from __doc__
    """
    set_timer(eventid, milliseconds) -> None
    repeatedly create an event on the event queue
    """
    pass

def wait(milliseconds): # real signature unknown; restored from __doc__
    """
    wait(milliseconds) -> time
    pause the program for an amount of time
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

