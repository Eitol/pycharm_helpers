# encoding: utf-8
# module Cython.Compiler.Pythran
# from /home/pi/.local/lib/python3.5/site-packages/Cython/Compiler/Pythran.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import Cython.Compiler.PyrexTypes as __Cython_Compiler_PyrexTypes


# functions

def has_np_pythran(*args, **kwargs): # real signature unknown
    pass

def include_pythran_generic(*args, **kwargs): # real signature unknown
    pass

def is_pythran_buffer(*args, **kwargs): # real signature unknown
    pass

def is_pythran_expr(*args, **kwargs): # real signature unknown
    pass

def is_pythran_supported_dtype(*args, **kwargs): # real signature unknown
    pass

def is_pythran_supported_node_or_none(*args, **kwargs): # real signature unknown
    pass

def is_pythran_supported_operation_type(*args, **kwargs): # real signature unknown
    pass

def is_pythran_supported_type(*args, **kwargs): # real signature unknown
    pass

def pythran_binop_type(*args, **kwargs): # real signature unknown
    pass

def pythran_func_type(*args, **kwargs): # real signature unknown
    pass

def pythran_indexing_code(*args, **kwargs): # real signature unknown
    pass

def pythran_indexing_type(*args, **kwargs): # real signature unknown
    pass

def pythran_type(*args, **kwargs): # real signature unknown
    pass

def pythran_unaryop_type(*args, **kwargs): # real signature unknown
    pass

def to_pythran(*args, **kwargs): # real signature unknown
    pass

def _index_code(*args, **kwargs): # real signature unknown
    pass

def _index_type_code(*args, **kwargs): # real signature unknown
    pass

# classes

class CType(__Cython_Compiler_PyrexTypes.PyrexType):
    # no doc
    def can_coerce_from_pyobject(self, env): # reliably restored by inspect
        # no doc
        pass

    def can_coerce_to_pyobject(self, env): # reliably restored by inspect
        # no doc
        pass

    def create_from_py_utility_code(self, env): # reliably restored by inspect
        # no doc
        pass

    def create_to_py_utility_code(self, env): # reliably restored by inspect
        # no doc
        pass

    def error_condition(self, result_code): # reliably restored by inspect
        # no doc
        pass

    def from_py_call_code(self, source_code, result_code, error_pos, code, from_py_function=None, error_condition=None): # reliably restored by inspect
        # no doc
        pass

    def to_py_call_code(self, source_code, result_code, result_type, to_py_function=None): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    exception_check = 1
    exception_value = None
    from_py_function = None
    to_py_function = None


class CStructOrUnionType(__Cython_Compiler_PyrexTypes.CType):
    # no doc
    def attributes_known(self): # reliably restored by inspect
        # no doc
        pass

    def can_be_complex(self): # reliably restored by inspect
        # no doc
        pass

    def can_coerce_from_pyobject(self, env): # reliably restored by inspect
        # no doc
        pass

    def can_coerce_to_pyobject(self, env): # reliably restored by inspect
        # no doc
        pass

    def cast_code(self, expr_code): # reliably restored by inspect
        # no doc
        pass

    def create_from_py_utility_code(self, env): # reliably restored by inspect
        # no doc
        pass

    def create_to_py_utility_code(self, env): # reliably restored by inspect
        # no doc
        pass

    def declaration_code(self, entity_code, for_display=0, dll_linkage=None, pyrex=0): # reliably restored by inspect
        # no doc
        pass

    def is_complete(self): # reliably restored by inspect
        # no doc
        pass

    def struct_nesting_depth(self): # reliably restored by inspect
        # no doc
        pass

    def __eq__(self, other): # reliably restored by inspect
        # no doc
        pass

    def __hash__(self): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, name, kind, scope, typedef_flag, cname, packed=False): # reliably restored by inspect
        # no doc
        pass

    def __lt__(self, other): # reliably restored by inspect
        # no doc
        pass

    def __repr__(self): # reliably restored by inspect
        # no doc
        pass

    exception_check = True
    has_attributes = 1
    is_struct_or_union = 1


class CTypedefType(__Cython_Compiler_PyrexTypes.BaseType):
    # no doc
    def as_argument_type(self): # reliably restored by inspect
        # no doc
        pass

    def can_coerce_from_pyobject(self, env): # reliably restored by inspect
        # no doc
        pass

    def can_coerce_to_pyobject(self, env): # reliably restored by inspect
        # no doc
        pass

    def cast_code(self, expr_code): # reliably restored by inspect
        # no doc
        pass

    def create_from_py_utility_code(self, env): # reliably restored by inspect
        # no doc
        pass

    def create_to_py_utility_code(self, env): # reliably restored by inspect
        # no doc
        pass

    def declaration_code(self, entity_code, for_display=0, dll_linkage=None, pyrex=0): # reliably restored by inspect
        # no doc
        pass

    def error_condition(self, result_code): # reliably restored by inspect
        # no doc
        pass

    def from_py_call_code(self, source_code, result_code, error_pos, code, from_py_function=None, error_condition=None): # reliably restored by inspect
        # no doc
        pass

    def invalid_value(self): # reliably restored by inspect
        # no doc
        pass

    def overflow_check_binop(self, binop, env, const_rhs=False): # reliably restored by inspect
        # no doc
        pass

    def py_type_name(self): # reliably restored by inspect
        # no doc
        pass

    def resolve(self): # reliably restored by inspect
        # no doc
        pass

    def specialize(self, values): # reliably restored by inspect
        # no doc
        pass

    def to_py_call_code(self, source_code, result_code, result_type, to_py_function=None): # reliably restored by inspect
        # no doc
        pass

    def _create_utility_code(self, template_utility_code, template_function_name): # reliably restored by inspect
        # no doc
        pass

    def __getattr__(self, name): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, name, base_type, cname, is_external=0, namespace=None): # reliably restored by inspect
        # no doc
        pass

    def __repr__(self): # reliably restored by inspect
        # no doc
        pass

    def __str__(self): # reliably restored by inspect
        # no doc
        pass

    from_py_utility_code = None
    is_typedef = 1
    subtypes = [
        'typedef_base_type',
    ]
    to_py_utility_code = None
    typedef_is_external = 0


# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

__test__ = {}

