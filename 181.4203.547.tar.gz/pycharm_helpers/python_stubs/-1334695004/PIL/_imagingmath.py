# encoding: utf-8
# module PIL._imagingmath
# from /usr/lib/python3/dist-packages/PIL/_imagingmath.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

abs_F = 1986833336
abs_I = 1986830368

add_F = 1986833520
add_I = 1986830596

and_I = 1986831568

diff_F = 1986833976
diff_I = 1986831316

div_F = 1986833844
div_I = 1986830992

eq_F = 1986834320
eq_I = 1986832500

ge_F = 1986835000
ge_I = 1986833196

gt_F = 1986834864
gt_I = 1986833056

invert_I = 1986831456

le_F = 1986834728
le_I = 1986832916

lshift_I = 1986831964

lt_F = 1986834592
lt_I = 1986832776

max_F = 1986834204
max_I = 1986832364

min_F = 1986834088
min_I = 1986832228

mod_F = 1986835408
mod_I = 1986831152

mul_F = 1986833736
mul_I = 1986830860

neg_F = 1986833428
neg_I = 1986830484

ne_F = 1986834456
ne_I = 1986832640

or_I = 1986831700

pow_F = 1986835588
pow_I = 1986835136

rshift_I = 1986832096

sub_F = 1986833628
sub_I = 1986830728

xor_I = 1986831832

# functions

def binop(*args, **kwargs): # real signature unknown
    pass

def unop(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

