# encoding: utf-8
# module PIL._webp
# from /usr/lib/python3/dist-packages/PIL/_webp.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

HAVE_WEBPMUX = True

# functions

def WebPDecode(*args, **kwargs): # real signature unknown
    """ WebPDecode """
    pass

def WebPDecoderBuggyAlpha(*args, **kwargs): # real signature unknown
    """ WebPDecoderBuggyAlpha """
    pass

def WebPDecoderVersion(*args, **kwargs): # real signature unknown
    """ WebPVersion """
    pass

def WebPEncode(*args, **kwargs): # real signature unknown
    """ WebPEncode """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

