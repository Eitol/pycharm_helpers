import time
if __name__ == '__main__':
    for i in range(10):
        print('here %s' % i)
        time.sleep(1)
    
    print('TEST SUCEEDED')
        
